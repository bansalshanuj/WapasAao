﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;

namespace WapasAao.UserControls
{
    public partial class SendCreditsUserControl : UserControl
    {
        public SendCreditsUserControl()
        {
            InitializeComponent();
        }
             
    }
}
